# Reel Playlist

Statt der For-You-Page läuft in Instagram deine eigene Liste weiter (Likes oder Gespeichert).
Instagram wird NICHT verändert; die App öffnet per Deeplink das jeweils nächste Reel aus deiner Liste.

## 1. Daten holen (einmalig, kann Minuten bis Tage dauern)
Instagram → Profil → ☰ → Konto-Center → Deine Informationen und Berechtigungen → Deine Informationen herunterladen
→ Bestimmte Informationen auswählen (Likes, Gespeichert) → Format **JSON** → Gesamter Zeitraum.
(Die Menünamen ändern sich ab und zu.) ZIP entpacken. Gesucht:
- `.../likes/liked_posts.json`
- `.../saved/saved_posts.json`
(Pfad kann leicht abweichen, z. B. mit Ordner `your_instagram_activity`.)

## 2. App bauen (PC, Android Studio)
Ordner öffnen → Gradle Sync (JDK 17 ist in Android Studio dabei; wenn nach Gradle gefragt wird: 8.7 oder neuer)
→ Handy per USB/Wireless-ADB verbinden → Run. Oder Build → Build APK(s) und die APK installieren.

## 3. Bedienungshilfe aktivieren
Einstellungen → Bedienungshilfen → Reel Playlist → an.
Android 13+ sperrt das bei Sideload-Apps ("Eingeschränkte Einstellung"). Lösung:
App-Info → ⋮ → "Eingeschränkte Einstellungen zulassen", oder per ADB:
    adb shell appops set de.local.reelplaylist ACCESS_RESTRICTED_SETTINGS allow

Falls Reels beim Weiterschalten nicht aus dem Hintergrund starten (neuere Android-Versionen sind streng):
    adb shell appops set de.local.reelplaylist SYSTEM_ALERT_WINDOW allow

## 4. Benutzen
1. Beide JSON-Dateien importieren.
2. Liste wählen (Likes / Gespeichert), "Start / Weiter" tippen. Instagram öffnet das erste Reel.
3. Weiter mit: Lautstärke leiser (nächstes), lauter (vorheriges), oder den schwebenden Buttons » « ✕.
4. Die Position wird gespeichert. Beim nächsten Mal "Start / Weiter" = dort weitermachen.

## 5. Swipe-Erkennung (experimentell)
Funktioniert nur, wenn Instagram seine Scroll-Ereignisse samt View-ID an die Bedienungshilfe meldet.
1. "Debug" einschalten, in Instagram im Reels-Viewer ein paar Mal wischen.
2. In der App unten im Debug-Log nach dem Eintrag suchen, der beim Reel-Wischen auftaucht
   (nicht bei Kommentaren o. Ä.). Ein Teil der ID (Standard: `clips_viewer`) muss darin vorkommen.
3. Passenden Teil als Pager-ID speichern, "Swipe-Erkennung" einschalten.
Wenn nichts Passendes im Log steht, nimm Lautstärketasten/Buttons.

## Hinweise
- Liste leer? "Nur /reel/-Links" ausschalten (manche Reels stehen im Export als /p/-Links).
- Reihenfolge: standardmäßig neueste zuerst (wie in Instagram); mit "umkehren" älteste zuerst.
- Der Dienst wertet nur den Paketnamen der Apps und Scroll-Ereignisse von Instagram aus. Es wird nichts gespeichert oder gesendet (die App hat keine Internet-Berechtigung).
- Der Quellcode wurde nicht kompiliert/getestet. Bei Fehlern: Meldung kopieren und weitergeben.
